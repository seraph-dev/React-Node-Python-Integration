# Supervised-Machine-Learning
Machine learning algorithm using KD trees to solve the classification problem.

The proposed problem was to implement a geometric algorithm for classification based on the K nearest neighbors.
Such a problem can be solved through a Supervised Machine Learning. On this occasion,
the algorithm receives training points to adjust the model that is used to classify test points.

Access 'Documentacao.pdf' (Portuguese version) to undertand every single function, every database used and your analysis,
implemented data structures (such as kd trees and priority queues) and the algorithm itself explained on every detail.
